package jdbc;

import java.sql.*;

// JDBC - Java Database Connectivity

public class App3 {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        System.out.println("Start");

        String className = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/traindb";

        String user = "root";
        String password = "Moandler@07";

        Class.forName(className);
        Connection con = DriverManager.getConnection(url, user, password);
        Statement st = con.createStatement();
        String sql = "select * from train";
        String query2 = "insert into train values(1006,'DA Express','Delhi','Ahmedabad',800.00)";
        String query3 = "update train set source = 'Bengaluru' where train_no=1006" ;
        String query4 = "delete from train where train_no=1004";

        System.out.println("All the Data in the table");
        ResultSet rs = st.executeQuery(sql);
        while(rs.next()) {
            System.out.println(rs.getInt(1) + " " + rs.getString(2)+ " " + rs.getString(3)+ " " + rs.getString(4)+ " " + rs.getDouble(5));
        }
        System.out.println();
        System.out.println("Inserting Data in the table");
        System.out.println();
        st.execute(query2);
        ResultSet rs1 = st.executeQuery(sql);
        while(rs1.next()) {
            System.out.println(rs1.getInt(1) + " " + rs1.getString(2) + " " + rs1.getString(3) + " " + rs1.getString(4) + " " + rs1.getDouble(5));

        }
        System.out.println();
        System.out.println("Updating a particular field in the table");
        System.out.println();
            st.execute(query3);
            ResultSet rs2 = st.executeQuery(sql);
            while(rs2.next()) {
                System.out.println(rs2.getInt(1) + " " + rs2.getString(2) + " " + rs2.getString(3) + " " + rs2.getString(4) + " " + rs2.getDouble(5));
            }
        System.out.println();
            System.out.println("Deleting Data in the table");
        System.out.println();
              st.execute(query4);
                ResultSet rs3 = st.executeQuery(sql);
                while(rs3.next()) {
                    System.out.println(rs3.getInt(1) + " " + rs3.getString(2) + " " + rs3.getString(3) + " " + rs3.getString(4) + " " + rs3.getDouble(5));
                }System.out.println("End");

    }

}