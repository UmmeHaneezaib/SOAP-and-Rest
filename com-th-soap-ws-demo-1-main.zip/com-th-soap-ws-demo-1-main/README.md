# com-th-soap-ws-demo-1
 SOAP Spring Boot Demo for TH Trainees Dec 2021
