//package com.torryharris.Spring.Boot.Example.controller;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import com.torryharris.Spring.Boot.Example.Repository.EmployeeRepository;
//import com.torryharris.Spring.Boot.Example.Service.EmployeeService;
//import com.torryharris.Spring.Boot.Example.model.Department;
//import com.torryharris.Spring.Boot.Example.model.Employee;
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//
//
//@ExtendWith(MockitoExtension.class)
//public class EmployeeServiceTests {
//
//    private static final Logger LOG = LoggerFactory.getLogger(EmployeeServiceTests.class);
//
//    @InjectMocks
//    private EmployeeService service;
//
//    @Mock
//    private EmployeeRepository repository;
//
//    private static List<Employee> empList;
//
//    @BeforeAll
//    public static void createEmpData() {
//        empList = new ArrayList<>();
//        empList.add(new Employee(101, "Sonu", 25000, new Department(10a));
//        empList.add(new Employee(102, "Monu", 35000, new Department(20)));
//        empList.add(new Employee(103, "Tonu", 30000, new Department(20)));
//    }
//
//    @Test
//    public void testGetAllEmployees() {
//        when(repository.findAll()).thenReturn(empList);
//        assertEquals(3, service.getAllEmployees().size());
//        verify(repository, times(1)).findAll();
//    }
//
//    @Test
//    public void testGetAllEmployeesTimes() {
//        when(repository.findAll()).thenReturn(empList);
//        service.getAllEmployees();
//        service.getAllEmployees();
//        service.getAllEmployees();
//        verify(repository, times(3)).findAll();
//    }
//
////	@Test
////	public void testGetEmployeeById() {
////		when(repository.findById(102).get()).thenReturn(empList.get(1));
////
////		service.getEmployeeById(102);
////		service.getEmployeeById(102);
////		service.getEmployeeById(102);
////
////		verify(repository, times(3)).findById(102);
////
//////		when(repository.findById(101).get()).thenReturn(empList.get(0));
//////		assertEquals(101, service.getEmployeeById(101).getEmployeeId());
////	}
//}