//package com.torryharris.Spring.Boot.Example.controller;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotEquals;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.HttpStatus;
//import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
//
//
////Java - JUnit
////JavaScript - jasmine
//
//@SpringJUnitConfig
//public class EmployeeControllerTests {
//
//    // 2 = 1+1 positive test case
//    // 2 != 1+2 negative test case
//
//    @Autowired
//   private EmployeeController employeeController;
//
//    // positive test case
//    @Test
//    public void testGetEmpById() {
//        HttpStatus expected = HttpStatus.OK;
//        HttpStatus actual = employeeController.getEmpById(1).getStatusCode();
//        assertEquals(expected, actual);
//    }
//
//    // negative test case
//    @Test
//    public void testGetEmpById2() {
//        HttpStatus unexpected = HttpStatus.NOT_FOUND;
//
//        HttpStatus actual = employeeController.getEmpById(1).getStatusCode(); // 200
//        assertNotEquals(unexpected, actual);
//    }
//        @Test
//        public void testGetEmpByName() {
//            String expected = "Sonu";
//            String actual = employeeController.getByEName("Sonu").get(0).geteName();
//            assertEquals(expected, actual);
//        }
//
//    }
//}
