package com.torryharris.Spring.Boot.Example.controller;
import com.torryharris.Spring.Boot.Example.Service.EmployeeService;
import com.torryharris.Spring.Boot.Example.model.Employee;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController("/employee")
    public class EmployeeController {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());
     @Autowired
    private EmployeeService employeeService;

    @GetMapping("/getempbyid/{eid}")
    public Employee getEmpById(@PathVariable(name = "eid") int eid) {
        LOG.info("getEmpById " + eid);
        return employeeService.getEmployeeById(eid);
    }
    @GetMapping("/getempbyname/{eName}")
    public List<Employee> getByEName(@PathVariable(name = "eName") String eName) {
        LOG.info("getEmpByEname " + eName);
        return employeeService.getByEName(eName);
    }
//    @GetMapping("/getempbysalary/{salary}")
//    public List<Employee> getByEName(@PathVariable(name = "eName") String eName) {
//        LOG.info("getEmpByEname " + eName);
//        return employeeService.getByEName(eName);
//    }


    @GetMapping("/emplist")
    public List<Employee> empList() {
        LOG.info("Employee List");
        return employeeService.getAllEmployees();

    }
    @PostMapping("/addemp")
    public ResponseEntity<Employee> addEmp(@RequestBody Employee emp) {
        LOG.info("addEmp " + emp.toString());
        Employee empTemp = employeeService.addEmployee(emp);
        HttpHeaders headers = new HttpHeaders();
        headers.add("message", "Employee added successfully."); // more can be added
        HttpStatus status = HttpStatus.CREATED;
        return new ResponseEntity<Employee>(empTemp, headers, status);
    }
//    @PostMapping("/addemp")
//    public Employee addemp(@RequestBody Employee emp){
//        LOG.info("Added List");
//        return employeeService.addEmployee(emp);

    @PutMapping("/updateemp")
    public Employee updateemp(@RequestBody Employee emp){
        LOG.info("Updated List");
        return employeeService.updateEmployee(emp);
    }
//    @DeleteMapping("/deletemp/{eid}")
//    public Employee delete(@PathVariable(name = "eid")int eid){
//        LOG.info("Deleted List"+eid);
//        return employeeService.deleteEmployee(eid);
//    }



}

