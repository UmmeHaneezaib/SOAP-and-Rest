package com.torryharris.Spring.Boot.Example.Exception;

public class DepartmentNameNotFoundException extends RuntimeException{
    private static final long serialVersionUID = 1L;

    public DepartmentNameNotFoundException() {
        super();
    }

    public DepartmentNameNotFoundException(String message) { // message = This department is not found.
        super(message);
    }
}
