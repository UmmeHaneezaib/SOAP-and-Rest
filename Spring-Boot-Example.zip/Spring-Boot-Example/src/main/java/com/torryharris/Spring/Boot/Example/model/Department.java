package com.torryharris.Spring.Boot.Example.model;

import javax.persistence.*;

@Entity
@Table(name = "department")
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "did")
    private int did;
    @Column(name = "dName")
    private String dName;
    @Column(name = "city")
    private String city;

       public Department(){

    }
    public Department(int did, String dName, String city) {
        this.did = did;
        this.dName = dName;
        this.city = city;
    }
    public Department( String dName, String city) {

        this.dName = dName;
        this.city = city;
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public String getdName() {
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
