package com.torryharris.Spring.Boot.Example.controller;

import com.torryharris.Spring.Boot.Example.Service.DepartmentService;
import com.torryharris.Spring.Boot.Example.model.Department;
import com.torryharris.Spring.Boot.Example.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController("/department")
public class DepartmentController {
    @Autowired
    private DepartmentService departmentService;
    @GetMapping("/deplist")
    public List<Department> depList() {

        return departmentService.getAllDepartments();

    }
    @GetMapping("/getdeptbyname/{dName}")
    public List<Department> getByDName(@PathVariable(name = "dName") String dName) {

        return departmentService.getByDName(dName);
    }
    @GetMapping("/getdeptbycity/{city}")
    public List<Department> getByDCity(@PathVariable(name = "city") String city) {
        return departmentService.getByDName(city);
    }
    @GetMapping("/getdepbyid/{did}")
    public Department getDeptById(@PathVariable(name = "did") int did) {

        return departmentService.getDepartmentById(did);
    }

    @PostMapping("/addDept")
    public ResponseEntity<Department> addDept(@RequestBody Department dept){
     Department depTemp = departmentService.addDepartment(dept);
    HttpHeaders headers = new HttpHeaders();
    headers.add("message", "Department successfully added."); // more can be added
    HttpStatus status = HttpStatus.CREATED;
        return new ResponseEntity<Department>(depTemp, headers, status);
    }
    @PutMapping("/updateDept")
    public Department updateDept(@RequestBody Department dept){
       return departmentService.updateDepartment(dept);
    }
    @DeleteMapping("/deletebyid/{did}")
    public void deleteById(@PathVariable(name = "did") int did){
         departmentService.deleteDepartment(did);
    }
}
