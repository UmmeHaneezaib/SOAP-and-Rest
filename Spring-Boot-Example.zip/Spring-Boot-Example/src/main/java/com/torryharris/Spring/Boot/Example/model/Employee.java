package com.torryharris.Spring.Boot.Example.model;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.http.HttpStatus;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "employee")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int eid;
    private String eName;
    private double salary;
    @ManyToOne
    @JoinColumn(name = "did")
    private Department department;

    public Employee(String eName, double Salary, Department department) {
        this.department = department;
        this.eName = eName;
        this.salary = salary;
    }

    public Employee(Department department) {
        this.department = department;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Employee() {
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Employee(int eid, String eName, double salary) {
        this.eid = eid;
        this.eName = eName;
        this.salary = salary;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return eid == employee.eid && Double.compare(employee.salary, salary) == 0 && eName.equals(employee.eName) && department.equals(employee.department);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eid, eName, salary, department);
    }
}



