package com.torryharris.Spring.Boot.Example;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class hello {
     @GetMapping("/hello")
    public String hello() {
         System.out.println("Hello World");
         return "hello world";
     }
         @GetMapping("/hi")
         public String hi(){
             System.out.println("Hello World");
             return "hi,How are you??";
    }
//    @GetMapping("/*")
//    public String errorPage(){
//        System.out.println("Hello World");
//        return "page you are looking for is not found";
//    }

}
