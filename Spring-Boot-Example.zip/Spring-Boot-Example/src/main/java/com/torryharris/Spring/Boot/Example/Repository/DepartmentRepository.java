package com.torryharris.Spring.Boot.Example.Repository;

import com.torryharris.Spring.Boot.Example.model.Department;
import com.torryharris.Spring.Boot.Example.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department,Integer> {
    public abstract List<Department> findBydName(String dName);
    public abstract List<Department> existsBydName(String dName);
    public abstract List<Department> findByCity(String city);

}
