package com.torryharris.Spring.Boot.Example.Service;

import com.torryharris.Spring.Boot.Example.Exception.DepartmentNameNotFoundException;
import com.torryharris.Spring.Boot.Example.Exception.DepartmentNotFoundException;
import com.torryharris.Spring.Boot.Example.Exception.EmployeeAlreadyExistsException;
import com.torryharris.Spring.Boot.Example.Repository.DepartmentRepository;
import com.torryharris.Spring.Boot.Example.Repository.EmployeeRepository;
import com.torryharris.Spring.Boot.Example.model.Department;
import com.torryharris.Spring.Boot.Example.model.Employee;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    @Autowired
    DepartmentRepository departmentRepository;

    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    public List<Department> getByDName(String dName) {
            return departmentRepository.findBydName(dName);
    }
    public List<Department> getByCity(String city) {

        return departmentRepository.findBydName(city);
    }

    public Department getDepartmentById(int did) {
        return departmentRepository.findById(did).get();
    }
    public Department updateDepartment(Department dep){

        return departmentRepository.save(dep);
    }
    public Department addDepartment(Department dep){
        return departmentRepository.save(dep);
    }
    public void deleteDepartment(int id)
    {
        departmentRepository.deleteById(id);
    }

}
